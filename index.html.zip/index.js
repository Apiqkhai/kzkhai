(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,1890,1417]]},
		{name:"index_atlas_2", frames: [[0,0,1890,1417]]},
		{name:"index_atlas_3", frames: [[0,0,1280,1001]]},
		{name:"index_atlas_4", frames: [[1282,866,639,737],[0,0,1080,1081],[0,1083,1280,853],[1082,0,864,864]]},
		{name:"index_atlas_5", frames: [[0,0,1192,324],[950,1637,805,200],[0,1356,1128,176],[0,1839,1067,134],[1028,1073,996,201],[1069,1839,820,170],[0,1534,1904,101],[1130,1276,888,200],[1028,842,908,229],[0,326,961,381],[0,1637,948,200],[0,709,512,512],[514,842,512,512],[1194,0,804,422],[963,424,720,416]]},
		{name:"index_atlas_6", frames: [[1686,770,345,60],[666,172,126,60],[0,0,794,170],[1016,764,341,87],[0,172,664,170],[1359,770,325,87],[1158,0,706,170],[0,362,889,142],[459,805,396,59],[0,792,457,61],[586,572,1084,66],[1866,128,143,58],[287,655,234,135],[1485,640,416,128],[0,655,285,133],[586,640,428,163],[1158,172,696,142],[1672,426,327,200],[891,426,633,144],[1686,832,280,68],[1866,0,69,126],[0,506,584,147],[1158,316,855,108],[1016,640,467,122],[796,0,360,360]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_36 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["index_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._324123 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib._422 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.D202110983296FinalDrawingwithColour = function() {
	this.initialize(img.D202110983296FinalDrawingwithColour);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2480,3154);


(lib.Female = function() {
	this.initialize(ss["index_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Gumball = function() {
	this.initialize(img.Gumball);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2490,3510);


(lib.JJKOkakoro = function() {
	this.initialize(img.JJKOkakoro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2490,3510);


(lib.JPEG01 = function() {
	this.initialize(img.JPEG01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3508,2480);


(lib.logo_upsi_2 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.photo_20230210_135133 = function() {
	this.initialize(ss["index_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.photo_20230403_214132 = function() {
	this.initialize(ss["index_atlas_5"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.photo_20240121_235628 = function() {
	this.initialize(ss["index_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.photo_20240122_002144 = function() {
	this.initialize(ss["index_atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.photo_20240122_021617 = function() {
	this.initialize(ss["index_atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.pngtreethreedimensionalinstagramiconpngimage_6618437 = function() {
	this.initialize(ss["index_atlas_6"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Untitled1 = function() {
	this.initialize(img.Untitled1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3480,2490);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_36();
	this.instance.setTransform(-297.9,-80.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-297.9,-80.8,596,162);


(lib.Page6_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_35();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,402.5,100);


(lib.Page6_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.photo_20240122_021617();
	this.instance.setTransform(0,0,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,242.9,242.9);


(lib.Page6_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.JJKOkakoro();
	this.instance.setTransform(0,0,0.0861,0.0861);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,214.5,302.3);


(lib.Page6_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Female();
	this.instance.setTransform(0,0,0.1646,0.1646);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,311.1,233.3);


(lib.Page6_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Gumball();
	this.instance.setTransform(0,0,0.0798,0.0798);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,198.6,280);


(lib.Page6_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.D202110983296FinalDrawingwithColour();
	this.instance.setTransform(0,0,0.0903,0.0903);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,224,284.9);


(lib.Page6_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000043").ss(1,1,1).p("EhBlAOPQALgKALgLQWg2ff0AAQfzAAWfWfQA+A+A8A/QB1B9BrCBQO7SCB6XaEgxwg9QQABAcAAAdQAAHCk/E/QkkEkmTAZ");
	this.shape.setTransform(419.775,392.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000043").s().p("EhBlA9RMAAAgvCIAWgVQWg2ff0AAQfzAAWfWfQA+A+A8A/QB1B9BrCBQO7SCB6XagEhBlg9QIP1AAIABA5QAAHCk/E/QkkEkmTAZg");
	this.shape_1.setTransform(419.775,392.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000033").s().p("EAxSA9RQh63au6yCQhriBh1h9Qg8g/g+g+Q2g2f/zAAQ/0AA2gWfIgVAVMAAAg5oQGTgZEkkkQE/k/AAnCIgBg5MCT8AAAMAAAB6hg");
	this.shape_2.setTransform(524.125,392.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,1049.3,786.2);


(lib.Page5_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_34();
	this.instance.setTransform(54.65,231.1,0.4974,0.4974);

	this.instance_1 = new lib.CachedBmp_33();
	this.instance_1.setTransform(0,162.75,0.4974,0.4974);

	this.instance_2 = new lib.CachedBmp_32();
	this.instance_2.setTransform(239.55,0,0.4974,0.4974);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,735,318.7);


(lib.Page5_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_31();
	this.instance.setTransform(587.4,274.1,0.4974,0.4974);

	this.instance_1 = new lib.CachedBmp_30();
	this.instance_1.setTransform(118.4,271.15,0.4974,0.4974);

	this.instance_2 = new lib.photo_20240122_002144();
	this.instance_2.setTransform(474,3,0.3001,0.3001);

	this.instance_3 = new lib.JPEG01();
	this.instance_3.setTransform(0,0,0.1019,0.1019);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,858.2,304);


(lib.Page5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000043").ss(1,1,1).p("EBRqgMCQnhCwopAAQzKAAtitiQtjtjAAzJQAAizATisEhRpADwQM3n0QGAAQXaAAQjQiQQjQkAAXaQAAEaglEK");
	this.shape.setTransform(522.55,390.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000033").s().p("EADPA8/QAkkJABkaQAA3awjwkQwjwh3aAAQwGAAs3HzMAAAhAvMBlNAAAQgTCsAACzQAATKNjNiQNiNjTJAAQIqAAHgixMAAABJBg");
	this.shape_1.setTransform(522.55,390.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000043").s().p("EhRpA8/MAAAg5PQM3nzQGAAQXaAAQjQhQQjQkAAXaQgBEagkEJgEAg0gW0QtjtiAAzKQAAizATisMA+FAAAMAAAAw9QngCxoqAAQzJAAtitjg");
	this.shape_2.setTransform(522.55,390.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,1047.1,782.7);


(lib.Page4_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._422();
	this.instance.setTransform(249.1,0,1.6005,1.6005,10.6872);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000043").ss(1,1,1).p("EgVJA9UQGu0UQUwWUAbwgbvAnQAAAQG7AAGkA3EgjAg9TQLLNxAASaQAAVbvKPIQvJPK1bAAQjfAAjVga");
	this.shape.setTransform(527.175,564.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000052").s().p("EgVJA9UQGu0UQUwWUAbwgbvAnQAAAQG7AAGkA3MAAAA/igEhSXAWLMAAAhTeMAvXAAAQLLNxAASaQAAVbvKPIQvJPK1bAAQjfAAjVgag");
	this.shape_1.setTransform(527.175,564.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000043").s().p("EhSXA9UMAAAgnJQDVAaDfAAQVbAAPJvKQPKvIAA1bQAAyarLtxMB1YAAAMAAAA7FQmkg3m7AAUgnQAAAgbwAbvQwUQWmuUUg");
	this.shape_2.setTransform(527.175,564.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,1056.4,957.7);


(lib.Page4_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_29();
	this.instance.setTransform(566.8,400.1,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_28();
	this.instance_1.setTransform(569.25,303.7,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_27();
	this.instance_2.setTransform(730.2,230.9,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_26();
	this.instance_3.setTransform(0,396.45,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_25();
	this.instance_4.setTransform(25.85,230.9,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_24();
	this.instance_5.setTransform(0,303.7,0.5,0.5);

	this.instance_6 = new lib.logo_upsi_2();
	this.instance_6.setTransform(667.9,0,0.3633,0.3633);

	this.instance_7 = new lib.photo_20240121_235628();
	this.instance_7.setTransform(20.9,0,0.1511,0.1511);

	this.instance_8 = new lib.CachedBmp_23();
	this.instance_8.setTransform(8.75,171.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,976.8,485.1);


(lib.Page4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_22();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,444,100);


(lib.Page3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_21();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,444.5,71);


(lib.Page3_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Untitled1();
	this.instance.setTransform(0,0,0.2644,0.2644);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,920.3,658.5);


(lib.Page2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_20();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,454,114.5);


(lib.Page2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(50,50,50,0)").ss(1,1,1).p("EgFyBE9QgRg/gQg/EglTA3/Mgs2AAAMAAAh87MCkTAAA");
	this.shape.setTransform(525.775,441.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00003D").s().p("EhEmBF6QqoqomvsPQpNwyh5zyQgbkWgEkgMAgEAAAQgRg+gPg/I/lAAQABlnAklZQAXjfAmjZIAShjQCBqlESpqQHOwTNotpUAc+gc9Ao8AAAQJHAAIhBcQByAWBwAbQaUGTWFYtUAXkAaXAC5AoHUAC4AoKgc9Ac8Ugc+Ac+go9AAAUgo8AAAgc+gc+g");
	this.shape_1.setTransform(907.731,872);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EBJRACSQgagaAAgkQAAgkAagaQAagYAkAAQAjAAAaAYQAaAaAAAkQAAAkgaAaQgaAagjAAQgkAAgagagEBF7ACSQgZgagBgkQABgkAZgaQAagYAkAAQAkAAAaAYQAaAaAAAkQAAAkgaAaQgaAagkAAQgkAAgagagEBCqACSQgagaABgkQgBgkAagaQAagYAkAAQAkAAAZAYQAaAaAAAkQAAAkgaAaQgZAagkAAQgkAAgagagEhElACSQgagaAAgkQAAgkAagZQAagZAkAAQAkAAAaAZQAaAZAAAkQAAAkgaAaQgaAagkAAQgkAAgagagEhH1ACSQgagaAAgkQAAgkAagZQAZgZAkAAQAkAAAaAZQAZAZAAAkQAAAkgZAaQgaAagkAAQgkAAgZgagEhLLACSQgagaAAgkQAAgkAagZQAZgZAlAAQAkAAAaAZQAZAZAAAkQAAAkgZAaQgaAagkAAQglAAgZgagEhMKgBJIAAhiMCYUAAAIAABig");
	this.shape_2.setTransform(531.2,81.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000033").s().p("EhSJA+dMAAAh86MCkTAAAMAAAAnlQhxgbhygWQohhcpHABUgo9AAAgc8Ac8QtpNpnOQTQkRJqiCKlI6CAAIAABiIZwAAQgmDZgXDfgEhDuAynQgTATgFAYICrAAQgFgYgTgTQgagagkAAQgkAAgZAagEhG/AynQgTATgFAYICrAAQgFgYgTgTQgagagkAAQgkAAgZAagEhKVAynQgTATgFAYICrAAQgFgYgSgTQgagagkAAQgkAAgaAagEhB1gNpQmKGLAAIsQAAIsGKGKQGKGLItgBQItABGKmLQGKmKAAosQAAosmKmLQmKmKotAAQotAAmKGKgEBKHgxXQgaAaAAAkQAAAlAaAZQAaAaAkAAQAkAAAZgaQAagZAAglQAAgkgagaQgZgZgkAAQgkAAgaAZgEBGxgxXQgZAaAAAkQAAAlAZAZQAaAaAkAAQAkAAAagaQAagZAAglQAAgkgagaQgagZgkAAQgkAAgaAZgEBDggxXQgZAaAAAkQAAAlAZAZQAaAaAkAAQAkAAAagaQAagZAAglQAAgkgagaQgagZgkAAQgkAAgaAZgEhDugxWQgaAaAAAjQAAAlAaAaQAZAZAkAAQAkAAAagZQAagaAAglQAAgjgagaQgagagkAAQgkAAgZAagEhG/gxWQgaAaAAAjQAAAlAaAaQAZAZAkAAQAkAAAagZQAagaAAglQAAgjgagaQgagagkAAQgkAAgZAagEhKVgxWQgaAaAAAjQAAAlAaAaQAaAZAkAAQAkAAAagZQAZgaAAglQAAgjgZgaQgagagkAAQgkAAgaAagEhLTgy3MCYUAAAIAAhhMiYUAAAg");
	this.shape_3.setTransform(525.775,399.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,1533.2,1505.8);


(lib.Page2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_19();
	this.instance.setTransform(0,77.3,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_18();
	this.instance_1.setTransform(15.55,41.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_17();
	this.instance_2.setTransform(82.05,0,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_16();
	this.instance_3.setTransform(1,3.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,624.1,106.8);


(lib.Page2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.photo_20230403_214132();
	this.instance.setTransform(0,0,0.7323,0.7323);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,527.3,304.7);


(lib.Page1_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_15();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,117,67.5);


(lib.Page1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_14();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,208,64);


(lib.Page1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_13();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,480.5,190.5);


(lib.P6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_12();
	this.instance.setTransform(37.2,1.55,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_11();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,214,81.5);


(lib.P5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#747474").s().p("AhiCHIkOiHILhlwIAABYIoyEYIENCHIElCTIAABXg");
	this.shape.setTransform(36.9,36.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BABABA").s().p("ADBEaIkjiTIkOiHIIxkYICwhYIAALhg");
	this.shape_1.setTransform(54.45,36.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,91.4,73.8);


(lib.P4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#747474").s().p("AhiCHIkOiHILhlwIAABYIoyEYIENCHIElCTIAABXg");
	this.shape.setTransform(36.9,36.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BABABA").s().p("ADBEaIkjiTIkOiHIIxkYICwhYIAALhg");
	this.shape_1.setTransform(54.45,36.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,91.4,73.8);


(lib.P3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#747474").s().p("AhiCHIkOiHILhlwIAABYIoyEYIENCHIElCTIAABXg");
	this.shape.setTransform(36.9,36.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BABABA").s().p("ADBEaIkjiTIkOiHIIxkYICwhYIAALhg");
	this.shape_1.setTransform(54.45,36.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,91.4,73.8);


(lib.P1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#747474").s().p("AhiCHIkOiHILhlwIAABYIoyEYIENCHIElCTIAABXg");
	this.shape.setTransform(36.9,36.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BABABA").s().p("ADBEaIkjiTIkOiHIIxkYICwhYIAALhg");
	this.shape_1.setTransform(54.45,36.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,91.4,73.8);


(lib.N2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#747474").s().p("AlwEaIEkiTIENiHIoxkYIAAhYILhFwIkOCHInTDqg");
	this.shape.setTransform(54.45,36.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BABABA").s().p("AlwlwICvBYIIyEYIkOCHIkkCTIivBXg");
	this.shape_1.setTransform(36.9,36.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,91.4,73.8);


(lib.Me = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.photo_20230210_135133();
	this.instance.setTransform(0,0,0.4166,0.4166);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,533.2,417);


(lib.Mouth = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgqBPIgNgBIgIgDIgLgBQgEgBgEgDIgCgCQAAgCACgEQACADAEAAIALgBIAOABIAMABIAygCQAWgCAHAAIAVAEIgCABIgOAFQgJADgRACQgVACgYAAIgQAAgAgCA2IgCgBIABgBIABAAIAAAAIAEAAIAAABIgBABIgDAAgAg+gNQgtgBglgHIgagHQgVgGgtgUQgRgIADgJQADgJAQACQAMACARAGIAcALQAyASBWABQBgAABMgOIA6gMQAigGAZAAQgBADgFACIgJACQgEACgIAJQgNANgiAIQg5AMg5AFQgrAEgqAAIgogBg");
	this.shape.setTransform(25.1269,7.9193);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(9));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,50.3,15.8);


(lib.Exp = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_10();
	this.instance.setTransform(98.9,144.55,0.5,0.5);

	this.instance_1 = new lib._2();
	this.instance_1.setTransform(0,0,0.273,0.273);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,516,386.9);


(lib.end = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_9();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,163.5,100);


(lib.Edu = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_8();
	this.instance.setTransform(108.1,146.1,0.493,0.493);

	this.instance_1 = new lib._2();
	this.instance_1.setTransform(0,0,0.273,0.273);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,516,386.9);


(lib.Symbol1copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApIAxQgLgIgEgJQgDgHgBgMQgCgNAFgMQAGgRARgJQAQgJATABQATACANALQAOAMAEATQAEASgIAQQgMAYgcAFIgLABQgTAAgSgNgAILAkQgOgJgGgOQgDgJgBgIQAAgHABgKQAEgOALgLQAMgLAOgDQAbgFATATQAMAKAEAQQAEARgGANQgFAPgNAKQgOAJgQABIgDAAQgOAAgNgJg");
	this.shape.setTransform(82.4155,43.0712);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AH0EaQgtgEgkgLQgSgGgHgJQgCgDAAgEQABgEAGAAIAIABQAOAEApAGIAMABQgagJgVgTQgYgVgMgdQgLgdgBg6QgEhLAOgnIABgCIgBABQgOAKgbAZQgaAZgPAKQgGAFgHABQgHACgEgFQgFgHAIgNQAUgaAmgjQAlggAcgOQAfgNAsgGQBSgLBKAOQBRARA5AuQAWARAoAsQAPARACALQABAKgFAQQgMAdgVAXIgcAaQgRAQgFAPQAOg0AZgxQAJgSgCgJQgBgIgLgLQgngpgYgRIADAPIAGAcQAFAagBANQAAARgKAhIgDAbQgDAIgGAOIgLAVQgUAhgkAUQgSALgUAFIAHAAQASgDAOgHIAPgHQAKgDAGAFQAEACACAEQABAFgCADQgCAEgGADQgdAOgRAEQgNADgXAAIgdAAIgUABQgnAAgYgCgAG+BWQgOADgMALQgLALgDAOQgCAKABAHQAAAJADAJQAGAOAOAJQAPAKAQgBQAPgBAOgJQAOgKAFgPQAFgOgEgRQgEgQgMgKQgOgPgUAAIgMABgApGEbIgcAAQgYAAgMgDQgSgEgcgOQgHgDgCgEQgCgDACgFQABgEADgCQAHgFAKADIAPAHQAOAHASADIAHAAQgUgFgSgLQgkgUgTghIgMgVQgGgOgDgIIgDgbQgKghAAgRQgBgNAFgaIAGgcIADgPQgZARgmApQgKALgCAIQgBAJAIASQAZAxANA0QgEgPgQgQIgcgaQgXgXgLgdQgFgQABgKQACgLAOgRQApgsAVgRQA6guBSgRQBIgOBTALQAtAGAdANQAdAOAlAgQAmAjAUAaQAIANgFAHQgEAFgHgCQgHgBgGgFQgPgKgagZQgbgZgOgKIgBgBIABACQAOAngDBLQgDA6gLAdQgLAdgYAVQgWATgZAJIALgBQAqgGAOgEIAIgBQAGAAABAEQABAEgDADQgHAJgSAGQgkALguAEQgXACgnAAIgUgBgAqfBsQgSAJgGARQgFAMACAOQABAMADAHQAFAJAKAIQAXAQAZgEQAcgFAMgYQAIgQgEgTQgEgTgOgMQgNgLgTgCIgFAAQgQAAgNAIgANvi5QgQgHgfgIQhogahygRQg3gIghAAQg0gBhEAPIh3AfQgWAGgEgLQgDgHAGgHQAEgFAIgEQATgIAhgIQBAgRAkgGQA4gLAvABQAlABBMANQB4AVA0AOQAoALAWAOQAhAVAIAeQgPgQgZgLgAttjRQAWgOAogLQA0gOB3gVQBNgNAmgBQAugBA4ALQAkAGBAARQAhAIATAIQAIAEAEAFQAGAHgCAHQgFALgWgGIh2gfQhEgPg1ABQggAAg4AIQhyARhoAaQgeAIgRAHQgZALgPAQQAJgeAggVg");
	this.shape_1.setTransform(91.9,28.3507);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},4).to({state:[]},1).wait(38));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,183.8,56.7);


(lib.click = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_7();
	this.instance.setTransform(0,57.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_6();
	this.instance_1.setTransform(52.65,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,140,91.8);


(lib.Bg1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(50,50,50,0)").ss(1,1,1).p("EhHKhJbQKaj4MAAAQaWAASpSpQGvGwEUHyMBpHAAAMAAAB5cMilxAAAIAA7iQxThItzplQkPi8j6jvQgkgjgkgkQypypAA6VQAA6XSpyoQCtiuC4iUQAYgjAagjQGgoqJMAAQARAAARABgEhYKg/sQH5mXJHjY");
	this.shape.setTransform(719.275,494.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#030231").s().p("AntDyQGgopJLAAIAiAAQpGDZn5GWQAYgjAagjg");
	this.shape_1.setTransform(209.375,55.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EAXNAlmQiuh3ididQiTiUhyihQlzoUAAquQgBt9J5p4QJ4p5N/AAQN9AAJ5J5QJ5J4AAN9QAAN+p5J5Qp5J4t9AAQqgAAoMlkgATZtEQpUJVAANKQAAK0GRIOQBYBzBrBrQB2B1B+BfQIGGAKmAAQNKAAJVpUQJUpVAAtLQAAtKpUpVQpVpUtKAAQtMAApUJUgEgTPgp/Mg4YAAAIAAhKMA4DAAAMBdlAAAIAABKg");
	this.shape_2.setTransform(922.55,562.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00033D").s().p("EgEnA/eQxThItzpkQkPi9j5jvIhJhHQyoypgB6WQAB6WSoyoQCuitC3iUQH5mXJHjZQKaj3L/gBQaWABSpSoQGxGwETHyQDFFjB1GEMg4DAAAIAABLMA4YAAAQCVIXABJTQgBaWyoSpQkbEbk2DYQpeGlrHClQnPBrn6ABQiVAAiSgKg");
	this.shape_3.setTransform(407.15,407.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000033").s().p("EhS4A8uIAA7iQCSAKCWAAQH6AAHPhsQLHilJemlQE2jXEbkbQSoyoAB6WQgBpViVoXMBdQAAAIAAhKMhdlAAAQh1mEjFlkMBpGAAAMAAAB5cgAUT0XQp5J4ABN+QAAKtFzIUQByCiCTCTQCdCeCuB2QIMFkKgABQN9AAJ5p5QJ5p5AAt9QAAt+p5p4Qp5p4t9AAQt/AAp4J4gEBISguYQgaAaAAAjQAAAkAaAZQAZAaAkAAQAjAAAZgaQAagZgBgkQABgjgagaQgZgZgjABQgkgBgZAZgEBEwguYQgZAaAAAjQAAAkAZAZQAZAaAjAAQAkAAAZgaQAagZgBgkQABgjgagaQgZgZgkABQgjgBgZAZgEBBaguYQgZAaAAAjQAAAkAZAZQAZAaAkAAQAkAAAZgaQAZgZAAgkQAAgjgZgaQgZgZgkABQgkgBgZAZgAZedSQh+heh2h2QhrhrhYhzQmSoOABqzQAAtLJUpUQJUpUNMAAQNKAAJVJUQJUJUAANLQAANKpUJVQpVJUtKAAQqmAAoGmAgAYYwSQoMIMAALkQAALEHeH+IAuAvQAjAjAjAhQH3HIK0AAQLlAAIMoMQIMoMAArlQAArkoMoMQoMoMrlAAQrlAAoMIMg");
	this.shape_4.setTransform(908.05,600.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,1440.6,991.6);


(lib.Art = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_5();
	this.instance.setTransform(118.05,143.45,0.4847,0.4847);

	this.instance_1 = new lib._2();
	this.instance_1.setTransform(0,0,0.273,0.273);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,516,386.9);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Page2_1("synched",0);
	this.instance.setTransform(0,-3,1,1,0,0,0,263.6,152.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(50,50,50,0)").ss(1,1,1).p("A9h6GMA7DAAAMAAAA0NMg7DAAAg");
	this.shape.setTransform(-18.375,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000033").s().p("A9haHMAAAg0NMA7DAAAMAAAA0Ng");
	this.shape_1.setTransform(-18.375,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-263.6,-168.1,527.3,336.2);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,19,28,39,66,75,84,109,118,139,149,162,166,174,184,195,204,205,209];
	// timeline functions:
	this.frame_0 = function() {
		this.Me.addEventListener("click", fl_ClickToGoToAndPlayFromFrame.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame()
		{
			this.gotoAndPlay(21);
		}
		
		this.N1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_2.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_2()
		{
			this.gotoAndPlay(41);
		}
		
		this.P1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_3.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_3()
		{
			this.gotoAndPlay(1);
		}
		
		this.Edu.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_4.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_4()
		{
			this.gotoAndPlay(120);
		}
		
		this.exp.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_5.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_5()
		{
			this.gotoAndPlay(156);
		}
		
		this.art.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_6.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_6()
		{
			this.gotoAndPlay(176);
		}
		
		this.End.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_8.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_8()
		{
			this.gotoAndPlay(206);
		}
		
		this.P3.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_9.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_9()
		{
			this.gotoAndPlay(141);
		}
		
		this.P4.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_10.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_10()
		{
			this.gotoAndPlay(168);
		}
		
		this.back.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_11.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_11()
		{
			this.gotoAndPlay(1);
		}
		
		this.P5.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_12.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_12()
		{
			this.gotoAndPlay(197);
		}
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.Me.addEventListener("click", fl_ClickToGoToAndPlayFromFrame.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame()
		{
			this.gotoAndPlay(21);
		}
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_28 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.N1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_2.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_2()
		{
			this.gotoAndPlay(41);
		}
		
		
		
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.P1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_3.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_3()
		{
			this.gotoAndPlay(1);
		}
	}
	this.frame_39 = function() {
		this.stop();
	}
	this.frame_66 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.Edu.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_4.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_4()
		{
			this.gotoAndPlay(120);
		}
	}
	this.frame_75 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.exp.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_5.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_5()
		{
			this.gotoAndPlay(156);
		}
	}
	this.frame_84 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.art.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_6.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_6()
		{
			this.gotoAndPlay(176);
		}
	}
	this.frame_109 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.End.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_8.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_8()
		{
			this.gotoAndPlay(206);
		}
	}
	this.frame_118 = function() {
		this.stop();
	}
	this.frame_139 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.P3.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_9.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_9()
		{
			this.gotoAndPlay(141);
		}
		this.stop();
	}
	this.frame_149 = function() {
		this.stop();
	}
	this.frame_162 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.P4.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_10.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_10()
		{
			this.gotoAndPlay(168);
		}
	}
	this.frame_166 = function() {
		this.stop();
	}
	this.frame_174 = function() {
		this.stop();
	}
	this.frame_184 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.P5.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_12.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_12()
		{
			this.gotoAndPlay(197);
		}
	}
	this.frame_195 = function() {
		this.stop();
	}
	this.frame_204 = function() {
		this.stop();
	}
	this.frame_205 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.back.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_11.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_11()
		{
			this.gotoAndPlay(1);
		}
	}
	this.frame_209 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(9).call(this.frame_28).wait(11).call(this.frame_39).wait(27).call(this.frame_66).wait(9).call(this.frame_75).wait(9).call(this.frame_84).wait(25).call(this.frame_109).wait(9).call(this.frame_118).wait(21).call(this.frame_139).wait(10).call(this.frame_149).wait(13).call(this.frame_162).wait(4).call(this.frame_166).wait(8).call(this.frame_174).wait(10).call(this.frame_184).wait(11).call(this.frame_195).wait(9).call(this.frame_204).wait(1).call(this.frame_205).wait(4).call(this.frame_209).wait(1));

	// Back
	this.back = new lib.P6();
	this.back.name = "back";
	this.back.setTransform(873.25,699.8,1,1,0,0,0,106.9,40.6);
	this.back._off = true;
	new cjs.ButtonHelper(this.back, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.back).wait(205).to({_off:false},0).wait(5));

	// Layer_38
	this.instance = new lib.Mouth("single",0);
	this.instance.setTransform(132.8,568.8,0.6773,0.6773);

	this.instance_1 = new lib.Symbol1copy("synched",0);
	this.instance_1.setTransform(149.55,500.95,0.6773,0.6773,0,0,0,92,28.4);

	this.instance_2 = new lib.CachedBmp_1();
	this.instance_2.setTransform(-13.6,400.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},205).wait(5));

	// Logo
	this.instance_3 = new lib._324123();
	this.instance_3.setTransform(491,458,0.1648,0.1648);

	this.instance_4 = new lib.pngtreethreedimensionalinstagramiconpngimage_6618437();
	this.instance_4.setTransform(491,226,0.2024,0.2024);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4},{t:this.instance_3}]},205).wait(5));

	// Text_1
	this.instance_5 = new lib.CachedBmp_3();
	this.instance_5.setTransform(321.7,551.95,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_2();
	this.instance_6.setTransform(411.25,309.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6},{t:this.instance_5}]},205).wait(5));

	// Text
	this.instance_7 = new lib.CachedBmp_4();
	this.instance_7.setTransform(292.2,29.3,0.5,0.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(205).to({_off:false},0).wait(5));

	// Layer_33
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000043").ss(1,1,1).p("EBvCg91MAAAB/jMheNAAAQ0bPD6rAAUghdAAAgXqgXqUgXpgXqAAAghdUAAAghcAXpgXqUAXqgXpAhdAAAQd7AAWDS6g");
	this.shape.setTransform(383.525,373.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000061").s().p("EgjUAjVQuoupAA0sQAA0sOouoQOpuoUrAAQUtAAOoOoQOoOoAAUsQAAUsuoOpQuoOo0tAAQ0rAAupuog");
	this.shape_1.setTransform(124.15,349.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000056").s().p("EgrbArcQyAyAAA5cQAA5cSAx/QR/x/ZcAAQZcAASAR/QSAR/AAZcQAAZcyASAQyAR/5cAAQ5cAAx/x/gEgnjgi6QuoOpAAUrQAAUtOoOpQOpOoUsAAQUsAAOouoQOoupAA0tQAA0ruoupQuouo0sAAQ0sAAupOog");
	this.shape_2.setTransform(151.25,346.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000043").s().p("Eg5GA5GUgXpgXpAAAghdUAAAghcAXpgXqUAXqgXpAhcAAAQd6gBWFS6QCnCQChCgUAXpAXqAAAAhcUAAAAhdgXpAXpQkzEzlND1Q0cPC6rAAUghcAAAgXqgXqgEgxcgvuQyAR/AAZdQAAZbSASAQR/R/ZdAAQZbAASAx/QSAyAAA5bQAA5dyAx/QyAx/5bAAQ5dAAx/R/g");
	this.shape_3.setTransform(189.75,373.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00003D").s().p("EgvFA/yQFMj0EzkzUAXqgXqAAAghcUAAAghdgXqgXqQigigioiPMBZUAAAMAAAB/jg");
	this.shape_4.setTransform(792.7125,386.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},205).wait(5));

	// Layer_36
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000061").ss(1,1,1).p("EhYAhC8MCwBAAAMAAACF5MiwBAAAg");
	this.shape_5.setTransform(549.675,416.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00003D").s().p("EhYABC9MAAAiF5MCwBAAAMAAACF5g");
	this.shape_6.setTransform(549.675,416.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_6},{t:this.shape_5}]},205).wait(5));

	// Text
	this.instance_8 = new lib.Page6_7("synched",0);
	this.instance_8.setTransform(708.45,531.4,0.0403,0.0403,0,0,0,202.2,50.9);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(175).to({_off:false},0).to({scaleX:0.9846,scaleY:0.9846,x:544.8,y:84.35,alpha:1},9).to({startPosition:0},12).to({regX:202.5,scaleX:0.0432,scaleY:0.0432,x:726,y:549.65,alpha:0},8).to({_off:true},1).wait(5));

	// Layer_39
	this.instance_9 = new lib.Page6_6("synched",0);
	this.instance_9.setTransform(715.35,553.25,0.0403,0.0403,0,0,0,121.6,121.6);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(175).to({_off:false},0).to({scaleX:0.9846,scaleY:0.9846,x:713.45,y:618.2,alpha:1},9).to({startPosition:0},12).to({regX:121.5,regY:122.7,scaleX:0.0432,scaleY:0.0432,x:733.4,y:573.1,alpha:0},8).to({_off:true},1).wait(5));

	// Pic4
	this.instance_10 = new lib.Page6_5("synched",0);
	this.instance_10.setTransform(718.5,540.6,0.0403,0.0403,0,0,0,104.2,151.3);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(175).to({_off:false},0).to({regY:151.5,scaleX:0.9846,scaleY:0.9846,x:790.4,y:309.2,alpha:1},9).to({startPosition:0},12).to({regX:105.3,regY:151.6,scaleX:0.0432,scaleY:0.0432,x:736.8,y:559.5,alpha:0},8).to({_off:true},1).wait(5));

	// Pic3
	this.instance_11 = new lib.Page6_4("synched",0);
	this.instance_11.setTransform(702.4,553.05,0.0403,0.0403,0,0,0,156.3,116.7);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(175).to({_off:false},0).to({scaleX:0.9846,scaleY:0.9846,x:397,y:613.35,alpha:1},9).to({startPosition:0},12).to({regX:157.3,regY:118,scaleX:0.0432,scaleY:0.0432,x:719.55,y:572.9,alpha:0},8).to({_off:true},1).wait(5));

	// Pic2
	this.instance_12 = new lib.Page6_3("synched",0);
	this.instance_12.setTransform(697.65,541.05,0.0403,0.0403,0,0,0,96.8,141.5);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(175).to({_off:false},0).to({regX:96.9,scaleX:0.9846,scaleY:0.9846,x:281.05,y:320.2,alpha:1},9).to({startPosition:0},12).to({regX:98.4,regY:142.3,scaleX:0.0432,scaleY:0.0432,x:714.45,y:560,alpha:0},8).to({_off:true},1).wait(5));

	// Pic1
	this.instance_13 = new lib.Page6_2("synched",0);
	this.instance_13.setTransform(708.1,540.95,0.0403,0.0403,0,0,0,111.7,144);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(175).to({_off:false},0).to({scaleX:0.9846,scaleY:0.9846,x:536.35,y:317.75,alpha:1},9).to({startPosition:0},12).to({regX:112.2,regY:144.7,scaleX:0.0432,scaleY:0.0432,x:725.65,y:559.9,alpha:0},8).to({_off:true},1).wait(5));

	// Pic
	this.P5 = new lib.P5();
	this.P5.name = "P5";
	this.P5.setTransform(689.35,557.35,0.0403,0.0403,0,0,0,44.6,37.2);
	this.P5.alpha = 0;
	this.P5._off = true;
	new cjs.ButtonHelper(this.P5, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.P5).wait(175).to({_off:false},0).to({regX:44.7,scaleX:0.9846,scaleY:0.9846,x:78.2,y:718.35,alpha:1},9).wait(12).to({regX:45.1,regY:38.2,scaleX:0.0432,scaleY:0.0432,x:705.55,y:577.5,alpha:0},8).to({_off:true},1).wait(5));

	// Bg
	this.instance_14 = new lib.Page6_1("synched",0);
	this.instance_14.setTransform(707.15,543.7,0.0403,0.0403,0,0,0,523.6,390.9);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(175).to({_off:false},0).to({scaleX:0.9846,scaleY:0.9846,x:513.1,y:384.9,alpha:1},9).to({startPosition:0},12).to({regX:524.1,regY:391.1,scaleX:0.0432,scaleY:0.0432,x:724.6,y:562.85,alpha:0},8).to({_off:true},1).wait(5));

	// Arrow
	this.instance_15 = new lib.P4();
	this.instance_15.setTransform(714.4,332.4,0.0318,0.0318,0,0,0,45.6,37.8);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;
	new cjs.ButtonHelper(this.instance_15, 0, 1, 1);

	this.P4 = new lib.P4();
	this.P4.name = "P4";
	this.P4.setTransform(76.45,718.25,1.0053,1.0053,0,0,0,45.7,37.9);
	this.P4._off = true;
	new cjs.ButtonHelper(this.P4, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(150).to({_off:false},0).to({_off:true,regX:45.7,regY:37.9,scaleX:1.0053,scaleY:1.0053,x:76.45,y:718.25,alpha:1},12).wait(48));
	this.timeline.addTween(cjs.Tween.get(this.P4).wait(150).to({_off:false},12).wait(5).to({regX:47,regY:39,scaleX:0.0437,scaleY:0.0437,x:708.9,y:340.65,alpha:0},7).to({_off:true},1).wait(35));

	// Text
	this.instance_16 = new lib.Page5_3("synched",0);
	this.instance_16.setTransform(725.15,315.65,0.0318,0.0318,0,0,0,368.3,159);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(150).to({_off:false},0).to({regX:368.4,regY:159.1,scaleX:1.0053,scaleY:1.0053,x:416.65,y:188.25,alpha:1},12).to({startPosition:0},5).to({regX:369.8,regY:161.5,scaleX:0.0437,scaleY:0.0437,x:723.7,y:317.65,alpha:0},7).to({_off:true},1).wait(35));

	// Pic
	this.instance_17 = new lib.Page5_2("synched",0);
	this.instance_17.setTransform(728,326.95,0.0318,0.0318,0,0,0,429.7,152.7);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(150).to({_off:false},0).to({regX:429.8,regY:152.8,scaleX:1.0053,scaleY:1.0053,x:506.8,y:545.8,alpha:1},12).to({startPosition:0},5).to({regX:430.5,regY:153.4,scaleX:0.0437,scaleY:0.0437,x:727.6,y:333.15,alpha:0},7).to({_off:true},1).wait(35));

	// Layer_20
	this.instance_18 = new lib.Page5_1("synched",0);
	this.instance_18.setTransform(728.1,321.85,0.0318,0.0318,0,0,0,522.5,390.3);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(150).to({_off:false},0).to({regX:522.7,regY:390.4,scaleX:1.0053,scaleY:1.0053,x:510,y:384.4,alpha:1},12).to({startPosition:0},5).to({regX:523.2,regY:391.6,scaleX:0.0437,scaleY:0.0437,x:727.7,y:326.15,alpha:0},7).to({_off:true},1).wait(35));

	// Arrow
	this.instance_19 = new lib.P3();
	this.instance_19.setTransform(703.35,114.85,0.0426,0.0426,0,0,0,47,37.6);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;
	new cjs.ButtonHelper(this.instance_19, 0, 1, 1);

	this.P3 = new lib.P3();
	this.P3.name = "P3";
	this.P3.setTransform(87.7,708.2,0.9921,0.9921,0,0,0,46.9,37.6);
	this.P3._off = true;
	new cjs.ButtonHelper(this.P3, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(119).to({_off:false},0).to({regX:46.9,scaleX:0.9921,scaleY:0.9921,x:87.7,y:708.2,alpha:1},10).to({_off:true},10).wait(71));
	this.timeline.addTween(cjs.Tween.get(this.P3).wait(129).to({_off:false},10).to({regX:48,regY:38,scaleX:0.05,scaleY:0.05,x:706.85,y:96.75,alpha:0},10).to({_off:true},1).wait(60));

	// Text
	this.instance_20 = new lib.Page4_1("synched",0);
	this.instance_20.setTransform(721.7,86.65,0.0426,0.0426,0,0,0,222.9,50.5);
	this.instance_20.alpha = 0;
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(119).to({_off:false},0).to({regX:223.1,scaleX:0.9921,scaleY:0.9921,x:515,y:51.75,alpha:1},10).to({startPosition:0},10).to({regX:223.8,regY:52,scaleX:0.05,scaleY:0.05,x:728.4,y:63.65,alpha:0},10).to({_off:true},1).wait(60));

	// Pic
	this.instance_21 = new lib.Page4_2("synched",0);
	this.instance_21.setTransform(722.2,101.65,0.0426,0.0426,0,0,0,489.2,242.8);
	this.instance_21.alpha = 0;
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(119).to({_off:false},0).to({regX:489.4,regY:242.9,scaleX:0.9921,scaleY:0.9921,x:526.65,y:400.95,alpha:1},10).to({startPosition:0},10).to({regX:489.7,regY:243.8,scaleX:0.05,scaleY:0.05,x:728.95,y:81.25,alpha:0},10).to({_off:true},1).wait(60));

	// Bg
	this.instance_22 = new lib.Page4_3("synched",0);
	this.instance_22.setTransform(721.45,97.25,0.0426,0.0426,0,0,0,528,478.7);
	this.instance_22.alpha = 0;
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(119).to({_off:false},0).to({regY:478.6,scaleX:0.9921,scaleY:0.9921,x:509.1,y:298.5,alpha:1},10).to({startPosition:0},10).to({regX:528.6,regY:479.7,scaleX:0.05,scaleY:0.05,x:728.1,y:76.1,alpha:0},10).to({_off:true},1).wait(60));

	// End
	this.instance_23 = new lib.end();
	this.instance_23.setTransform(918.4,705.9,1,1,0,0,0,81.7,50);
	this.instance_23.alpha = 0;
	this.instance_23._off = true;
	new cjs.ButtonHelper(this.instance_23, 0, 1, 1);

	this.End = new lib.end();
	this.End.name = "End";
	this.End.setTransform(918.4,705.9,1,1,0,0,0,81.7,50);
	new cjs.ButtonHelper(this.End, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_23}]},101).to({state:[{t:this.End}]},8).to({state:[]},96).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(101).to({_off:false},0).to({_off:true,alpha:1},8).wait(101));

	// Artwork
	this.instance_24 = new lib.Art();
	this.instance_24.setTransform(514.1,562.5,0.0649,1,0,0,0,258.1,193.4);
	this.instance_24.alpha = 0;
	this.instance_24._off = true;
	new cjs.ButtonHelper(this.instance_24, 0, 1, 1);

	this.art = new lib.Art();
	this.art.name = "art";
	this.art.setTransform(724.3,579.65,1.0316,1,0,0,0,258.1,193.4);
	new cjs.ButtonHelper(this.art, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_24}]},75).to({state:[{t:this.art}]},9).to({state:[]},121).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(75).to({_off:false},0).to({_off:true,scaleX:1.0316,x:724.3,y:579.65,alpha:1},9).wait(126));

	// Experience
	this.instance_25 = new lib.Exp();
	this.instance_25.setTransform(489.55,341.4,0.0302,1,0,0,0,258.1,193.4);
	this.instance_25.alpha = 0;
	this.instance_25._off = true;
	new cjs.ButtonHelper(this.instance_25, 0, 1, 1);

	this.exp = new lib.Exp();
	this.exp.name = "exp";
	this.exp.setTransform(726.9,341.5,0.9971,1,0,0,0,259.8,193.5);
	new cjs.ButtonHelper(this.exp, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_25}]},66).to({state:[{t:this.exp}]},9).to({state:[]},130).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(66).to({_off:false},0).to({_off:true,regX:259.8,regY:193.5,scaleX:0.9971,x:726.9,y:341.5,alpha:1},9).wait(135));

	// Education
	this.instance_26 = new lib.Edu();
	this.instance_26.setTransform(487.55,124.4,0.038,1,0,0,0,254.2,193.4);
	this.instance_26.alpha = 0;
	this.instance_26._off = true;
	new cjs.ButtonHelper(this.instance_26, 0, 1, 1);

	this.Edu = new lib.Edu();
	this.Edu.name = "Edu";
	this.Edu.setTransform(726.4,93.8,1.0142,1,0,0,0,256.3,193.4);
	new cjs.ButtonHelper(this.Edu, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_26}]},57).to({state:[{t:this.Edu}]},9).to({state:[]},139).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(57).to({_off:false},0).to({_off:true,regX:256.3,scaleX:1.0142,x:726.4,y:93.8,alpha:1},9).wait(144));

	// Text
	this.instance_27 = new lib.Page3_2("synched",0);
	this.instance_27.setTransform(-238.2,112.45,1,1,0,0,0,222.2,35.6);
	this.instance_27.alpha = 0;
	this.instance_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(84).to({_off:false},0).wait(1).to({regY:35.5,x:-207.5,y:112.35,alpha:0.0625},0).wait(1).to({x:-176.8,alpha:0.125},0).wait(1).to({x:-146.1,alpha:0.1875},0).wait(1).to({x:-115.4,alpha:0.25},0).wait(1).to({x:-84.7,alpha:0.3125},0).wait(1).to({x:-54.05,alpha:0.375},0).wait(1).to({x:-23.35,alpha:0.4375},0).wait(1).to({x:7.35,alpha:0.5},0).wait(1).to({x:38.05,alpha:0.5625},0).wait(1).to({x:68.75,alpha:0.625},0).wait(1).to({x:99.4,alpha:0.6875},0).wait(1).to({x:130.1,alpha:0.75},0).wait(1).to({x:160.8,alpha:0.8125},0).wait(1).to({x:191.5,alpha:0.875},0).wait(1).to({x:222.2,alpha:0.9375},0).wait(1).to({x:252.85,alpha:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).to({_off:true},1).wait(5));

	// Pic
	this.instance_28 = new lib.Page3_11("synched",0);
	this.instance_28.setTransform(-55.4,793.3,0.1502,0.1502,0,0,0,460.1,328.9);
	this.instance_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(40).to({_off:false},0).wait(1).to({regY:329.2,scaleX:0.2646,scaleY:0.2646,x:-24.15,y:748.2},0).wait(1).to({scaleX:0.3789,scaleY:0.3789,x:7.05,y:703.05},0).wait(1).to({scaleX:0.4933,scaleY:0.4933,x:38.25,y:657.9},0).wait(1).to({scaleX:0.6077,scaleY:0.6077,x:69.5,y:612.75},0).wait(1).to({scaleX:0.722,scaleY:0.722,x:100.7,y:567.6},0).wait(1).to({scaleX:0.8364,scaleY:0.8364,x:131.95,y:522.5},0).wait(1).to({scaleX:0.9508,scaleY:0.9508,x:163.15,y:477.35},0).wait(1).to({scaleX:1.0651,scaleY:1.0651,x:194.35,y:432.2},0).wait(1).to({scaleX:1.1795,scaleY:1.1795,x:225.6,y:387.1},0).wait(1).to({scaleX:1.2939,scaleY:1.2939,x:256.8,y:341.95},0).wait(1).to({scaleX:1.1547,scaleY:1.1547,x:226.95,y:387.75},0).wait(1).to({scaleX:1.0156,scaleY:1.0156,x:197.1,y:433.6},0).wait(1).to({scaleX:0.8765,scaleY:0.8765,x:167.2,y:479.4},0).wait(1).to({scaleX:0.935,scaleY:0.935,x:181.55,y:460.1},0).wait(1).to({scaleX:0.9936,scaleY:0.9936,x:195.85,y:440.8},0).wait(1).to({scaleX:1.0522,scaleY:1.0522,x:210.15,y:421.5},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).to({_off:true},1).wait(5));

	// Bg
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#00004B").ss(1,1,1).p("ALY12QAAbFzJTKQzKTK7GAAQnJAAmnhWQyZjuuHuGQzJzKAA7FQAA7GTJzKQTKzKbGAAQbGAATKTKQBhBhBZBkQQPSOAAY9gEB3bAqOQAASrtMNMQtMNMyqAAQyqAAtMtMQk7k7jFlsQlMpjAArtQAAyqNMtMQNMtKSqAAQSqAANMNKQC2C3CPDGQIHLRAAOog");
	this.shape_7.setTransform(385.25,387.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("EAMyBAQMhmUAAAIAA1REgaohAPMB0LAAAMAAABRW");
	this.shape_8.setTransform(524.55,382.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00004B").s().p("EAqjBKFQk7k7jFlsQlMpjAArtQAAyqNMtLQNMtMSqAAQSqAANMNMQC2C2CPDGQIHLRAAOoQAASqtMNNQtMNLyqABQyqgBtMtLgEhDxAqNQyZjuuHuHQzJzJAA7FQAA7GTJzKQTKzKbHABQbFgBTKTKQBhBhBZBkQQPSOAAY9QAAbFzJTJQzKTL7FAAQnKAAmnhWg");
	this.shape_9.setTransform(385.25,387.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00003D").s().p("EhZiBAQIAA1RQGnBVHKAAQbFAATKzKQTKzJAA7FQAA49wQyOMB0LAAAMAAABRWQiPjHi2i2QtMtLyqAAQyqAAtMNLQtMNMAASqQAALtFMJjg");
	this.shape_10.setTransform(524.55,382.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]},40).to({state:[]},165).wait(5));

	// Arrow
	this.instance_29 = new lib.P1();
	this.instance_29.setTransform(1149.4,712.3,1,1,0,0,0,45.6,36.9);
	this.instance_29._off = true;
	new cjs.ButtonHelper(this.instance_29, 0, 1, 1);

	this.P1 = new lib.P1();
	this.P1.name = "P1";
	this.P1.setTransform(88,712.3,1,1,0,0,0,45.6,36.9);
	new cjs.ButtonHelper(this.P1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_29}]},20).to({state:[{t:this.P1}]},8).to({state:[]},12).wait(170));
	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(20).to({_off:false},0).to({_off:true,x:88},8).wait(182));

	// Layer_43
	this.instance_30 = new lib.N2();
	this.instance_30.setTransform(2029.05,712.3,1,1,0,0,0,45.6,36.9);
	this.instance_30._off = true;
	new cjs.ButtonHelper(this.instance_30, 0, 1, 1);

	this.N1 = new lib.N2();
	this.N1.name = "N1";
	this.N1.setTransform(967.65,712.3,1,1,0,0,0,45.6,36.9);
	new cjs.ButtonHelper(this.N1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_30}]},20).to({state:[{t:this.N1}]},8).to({state:[]},12).wait(170));
	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(20).to({_off:false},0).to({_off:true,x:967.65},8).wait(182));

	// Text_2
	this.instance_31 = new lib.Tween2("synched",0);
	this.instance_31.setTransform(1736.45,490.2);
	this.instance_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(20).to({_off:false},0).to({x:675.05,y:481.5},8).to({_off:true},12).wait(170));

	// Text_1
	this.instance_32 = new lib.Page2_2("synched",0);
	this.instance_32.setTransform(1750.65,293.4,1,1,0,0,0,312.1,53.3);
	this.instance_32._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(20).to({_off:false},0).to({x:689.25},8).to({_off:true},12).wait(170));

	// Text
	this.instance_33 = new lib.Page2_4("synched",0);
	this.instance_33.setTransform(1587.25,101.35,1,1,0,0,0,227.1,57.3);
	this.instance_33._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_33).wait(20).to({_off:false},0).to({x:525.85},8).to({_off:true},12).wait(170));

	// Layer_14
	this.instance_34 = new lib.Page2_3("synched",0);
	this.instance_34.setTransform(1827.2,731.75,1,1,0,0,0,765.8,752.1);
	this.instance_34._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(20).to({_off:false},0).to({x:765.8},8).to({_off:true},12).wait(170));

	// Pic
	this.instance_35 = new lib.Tween1("synched",0);
	this.instance_35.setTransform(194.6,395.3);
	this.instance_35.alpha = 0;
	this.instance_35._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_35).wait(20).to({_off:false},0).to({startPosition:0},8).to({startPosition:0},1).to({alpha:1},5).to({_off:true},6).wait(170));

	// Layer_3
	this.instance_36 = new lib.click("synched",0);
	this.instance_36.setTransform(802.7,732.9,1,0.0916,0,0,0,69.9,43.1);
	this.instance_36._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_36).wait(9).to({_off:false},0).wait(1).to({regX:70,regY:45.9,scaleY:0.1952,x:802.8,y:728.8},0).wait(1).to({scaleY:0.2989,y:724.45},0).wait(1).to({scaleY:0.4025,y:720.1},0).wait(1).to({scaleY:0.5061,y:715.8},0).wait(1).to({scaleY:0.6097,y:711.45},0).wait(1).to({scaleY:0.7134,y:707.15},0).wait(1).to({scaleY:0.817,y:702.8},0).wait(1).to({scaleY:0.9206,y:698.45},0).wait(1).to({scaleY:1.0242,y:694.1},0).wait(1).to({scaleY:1.1279,y:689.75},0).to({_off:true},1).wait(190));

	// Sign
	this.instance_37 = new lib.Page1_3("synched",0);
	this.instance_37.setTransform(62.4,738.55,1,1,0,0,0,58.6,33.9);
	this.instance_37.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_37).to({alpha:1},9).to({_off:true},11).wait(190));

	// Text_3
	this.instance_38 = new lib.Page1_2("synched",0);
	this.instance_38.setTransform(166.55,522.55,1,1,0,0,0,104,31.9);
	this.instance_38.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_38).to({alpha:1},9).to({_off:true},11).wait(190));

	// Text_2
	this.instance_39 = new lib.Page1_1("synched",0);
	this.instance_39.setTransform(302.65,373.05,1,1,0,0,0,240.1,95.2);
	this.instance_39.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_39).to({alpha:1},9).to({_off:true},11).wait(190));

	// Layer_9
	this.instance_40 = new lib.Bg1("synched",0);
	this.instance_40.setTransform(317,277.6,1,1,0,0,0,719.2,494.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_40).to({_off:true},20).wait(190));

	// Pic
	this.Me = new lib.Me();
	this.Me.name = "Me";
	this.Me.setTransform(792.6,428.5,1,1,0,0,0,266.6,208.5);
	this.Me.alpha = 0;
	new cjs.ButtonHelper(this.Me, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.Me).to({alpha:1},9).to({_off:true},11).wait(190));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(51.6,165.8,2542,1318.7);
// library properties:
lib.properties = {
	id: '39F4DCF0D6395D45B709175F756DC0A7',
	width: 1024,
	height: 768,
	fps: 24,
	color: "#00003D",
	opacity: 1.00,
	manifest: [
		{src:"images/D202110983296FinalDrawingwithColour.jpg", id:"D202110983296FinalDrawingwithColour"},
		{src:"images/Gumball.jpg", id:"Gumball"},
		{src:"images/JJKOkakoro.jpg", id:"JJKOkakoro"},
		{src:"images/JPEG01.jpg", id:"JPEG01"},
		{src:"images/Untitled1.png", id:"Untitled1"},
		{src:"images/index_atlas_1.png", id:"index_atlas_1"},
		{src:"images/index_atlas_2.png", id:"index_atlas_2"},
		{src:"images/index_atlas_3.png", id:"index_atlas_3"},
		{src:"images/index_atlas_4.png", id:"index_atlas_4"},
		{src:"images/index_atlas_5.png", id:"index_atlas_5"},
		{src:"images/index_atlas_6.png", id:"index_atlas_6"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['39F4DCF0D6395D45B709175F756DC0A7'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;